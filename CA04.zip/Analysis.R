setwd("C:/Users/sabrina/Desktop/CA04")
data_analysis <- read.csv(file="writeFile2.csv", header = T)
summary(data_analysis)


plot(data_analysis$Day, data_analysis$Author)
